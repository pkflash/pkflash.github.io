@echo off
setlocal enabledelayedexpansion

:: === CONFIGURATION ===
set BOOTLOADER_URL=https://raw.githubusercontent.com/HandHeldLegend/HOJA-ESP32-Baseband/master/build/bootloader/bootloader.bin
set PARTITIONS_URL=https://raw.githubusercontent.com/HandHeldLegend/HOJA-ESP32-Baseband/master/build/partition_table/partition-table.bin
set FIRMWARE_URL=https://raw.githubusercontent.com/HandHeldLegend/HOJA-ESP32-Baseband/master/build/ESP32.bin
set BOOTLOADER_OFFSET=0x1000
set PARTITIONS_OFFSET=0x8000
set FIRMWARE_OFFSET=0x10000
set TMP_DIR=%~dp0firmware_temp

echo ===============================================
echo       HOJA ESP32 Baseband Flasher
echo ===============================================
echo.

:: Create temp directory
if not exist "%TMP_DIR%" mkdir "%TMP_DIR%"

:: === CHECK FOR esptool.exe ===
if not exist "%~dp0esptool.exe" (
    echo [ERROR] esptool.exe not found in current directory.
    echo Please place esptool.exe in the same folder as this script.
    echo.
    pause
    exit /b 1
)

:: === DOWNLOAD FIRMWARE FILES ===
echo Downloading firmware files...
echo.

echo [1/3] Downloading bootloader...
curl -L --progress-bar "%BOOTLOADER_URL%" -o "%TMP_DIR%\bootloader.bin"
if errorlevel 1 (
    echo [ERROR] Failed to download bootloader
    goto :ERROR
)

echo [2/3] Downloading partition table...
curl -L --progress-bar "%PARTITIONS_URL%" -o "%TMP_DIR%\partitions.bin"
if errorlevel 1 (
    echo [ERROR] Failed to download partition table
    goto :ERROR
)

echo [3/3] Downloading firmware...
curl -L --progress-bar "%FIRMWARE_URL%" -o "%TMP_DIR%\firmware.bin"
if errorlevel 1 (
    echo [ERROR] Failed to download firmware
    goto :ERROR
)

:: === VERIFY FILES EXIST ===
if not exist "%TMP_DIR%\bootloader.bin" (
    echo [ERROR] Bootloader file not found after download
    goto :ERROR
)
if not exist "%TMP_DIR%\partitions.bin" (
    echo [ERROR] Partition table file not found after download
    goto :ERROR
)
if not exist "%TMP_DIR%\firmware.bin" (
    echo [ERROR] Firmware file not found after download
    goto :ERROR
)

echo.
echo Download complete!
echo.

:: === FLASHING ===
echo ===============================================
echo Starting ESP32 flash process...
echo ===============================================
echo.
echo INSTRUCTIONS:
echo 1. CLOSE any web browsers or IDE environments with COM port access
echo 2. Connect your gamepad in baseband update mode:
echo    - Unplug Gamepad
echo 	- Hold Start/Plus and R Bumper
echo    - Keep those buttons held, and plug in
echo    - The lights should be flashing orange, indicating baseband update mode
echo 3. Press any key to proceed with flashing...
echo.
pause

echo Erasing ESP32 flash memory...
echo.

esptool.exe --chip esp32 --baud 460800 erase-flash
if errorlevel 1 (
    echo [ERROR] Failed to erase flash memory
    goto :FLASH_ERROR
)

echo.
echo Flash erased successfully!
echo.
echo Flashing ESP32 (this may take a few minutes)...
echo.

esptool.exe --chip esp32 --baud 460800 --before default-reset --after hard-reset write-flash ^
  %BOOTLOADER_OFFSET% "%TMP_DIR%\bootloader.bin" ^
  %PARTITIONS_OFFSET% "%TMP_DIR%\partitions.bin" ^
  %FIRMWARE_OFFSET% "%TMP_DIR%\firmware.bin"

if errorlevel 1 goto :FLASH_ERROR

echo.
echo ===============================================
echo [SUCCESS] ESP32 flash complete!
echo ===============================================
echo.
echo Your Gamepad should now be running the HOJA baseband firmware.
echo Unplug your Gamepad to complete the update.
echo.
goto :CLEANUP

:FLASH_ERROR
echo.
echo ===============================================
echo [ERROR] Flash operation failed
echo ===============================================
echo.
echo Troubleshooting steps:
echo 1. Make sure ESP32 is in bootloader mode:
echo    - Hold BOOT button, press RESET, release BOOT
echo 2. Check USB cable (must support data, not just power)
echo 3. Install ESP32 USB drivers if needed
echo 4. Try a different USB port
echo 5. Make sure no other programs are using the COM port
echo.
goto :CLEANUP

:ERROR
echo.
echo ===============================================
echo [ERROR] Operation failed
echo ===============================================
echo.
echo Please check:
echo 1. Internet connection
echo 2. Firewall/antivirus settings
echo 3. GitHub repository accessibility
echo.

:CLEANUP
echo Cleaning up temporary files...
if exist "%TMP_DIR%" rd /s /q "%TMP_DIR%" >nul 2>&1
echo.
pause
exit /b